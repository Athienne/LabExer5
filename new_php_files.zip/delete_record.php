<?php 

include_once('connects.php');
$name = $_GET['name'];

$result = mysqli_query($con,"DELETE FROM student_data 
WHERE name = '$name'");
echo "Data Deleted";

?>