<?php 

include_once('connects.php');
$student_ID = $_GET['student_ID'];
$name = $_GET['name'];
$school =  $_GET['school'];
$country = $_GET['country'];
$gender =  $_GET['gender'];

$result = mysqli_query($con,"UPDATE student_data 
SET name = '$name', school = '$school', country = '$country', gender = '$gender' WHERE student_ID = '$student_ID'");
echo "Data Updated";

?>