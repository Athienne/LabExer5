<?php

include_once('connects.php');
$name = $_GET['name'];

$query = "SELECT * FROM `student_data` WHERE name LIKE '%". $name ."%'";
$check=mysqli_query($con,$query);
$row=mysqli_num_rows($check);
$myArray = array();

if($check == FALSE) { 
    echo ".".$row."."; // TODO: better error handling
}

  while($row=mysqli_fetch_array($check))
  	{
  	
	 $myArray[] = $row;
	
  	}
  echo json_encode($myArray);

?>