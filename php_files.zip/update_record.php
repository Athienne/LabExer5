<?php 

include_once('connects.php');
$name = $_GET['name'];
$school =  $_GET['school'];
$country = $_GET['country'];
$gender =  $_GET['gender'];

$result = mysqli_query($con,"UPDATE student_data 
SET name = '$name', school = '$school', country = '$country', gender = '$gender' WHERE name = '$name' and school = '$school' and country = '$country' and gender = '$gender'");
echo "Data Updated";

?>